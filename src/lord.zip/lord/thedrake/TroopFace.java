package lord.thedrake;

public enum TroopFace {
    AVERS, REVERS
}
