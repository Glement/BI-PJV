package lord.thedrake;

public enum PlayingSide {
    ORANGE, BLUE
}
