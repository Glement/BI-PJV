package lord.thedrake;

public interface Tile {
    public boolean canStepOn();
    public boolean hasTroop();
}
